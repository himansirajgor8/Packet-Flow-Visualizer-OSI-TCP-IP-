# Packet Flow Visualizer

A small Python GUI that demonstrates encapsulation for a message across OSI and TCP/IP layers.

## What it shows
- Application layer: raw data
- Transport layer: TCP segment
- Internet layer: IP packet
- Network access layer: Ethernet frame

## Run
```powershell
python app.py
```

No external packages are required (uses built-in `tkinter`).
