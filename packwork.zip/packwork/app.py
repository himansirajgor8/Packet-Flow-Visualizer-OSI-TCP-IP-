﻿import tkinter as tk
from tkinter import ttk
from dataclasses import dataclass
from datetime import datetime


@dataclass
class LayerStep:
    name: str
    model: str
    action: str


class PacketFlowVisualizer:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Packet Flow Visualizer - OSI + TCP/IP")
        self.root.geometry("1180x760")
        self.root.minsize(980, 680)

        self.steps = [
            LayerStep("Application", "OSI L7-5 / TCP-IP Application", "Raw message data is created by the sender application."),
            LayerStep("Transport", "OSI L4 / TCP", "TCP header is added -> data becomes a TCP segment."),
            LayerStep("Internet", "OSI L3 / IP", "IP header is added -> segment becomes an IP packet."),
            LayerStep("Network Access", "OSI L2-L1 / Link+Physical", "Frame header/trailer are added -> packet becomes a frame on the wire."),
        ]

        self.current_step = -1
        self.is_running = False
        self.after_id = None

        self._build_styles()
        self._build_ui()
        self._render_idle_state()

    def _build_styles(self) -> None:
        self.palette = {
            "bg": "#0f172a",
            "panel": "#111827",
            "panel_alt": "#1f2937",
            "text": "#e5e7eb",
            "muted": "#9ca3af",
            "accent": "#06b6d4",
            "accent_2": "#22c55e",
            "warn": "#f59e0b",
            "danger": "#ef4444",
        }

        self.root.configure(bg=self.palette["bg"])

        style = ttk.Style(self.root)
        style.theme_use("clam")

        style.configure("Main.TFrame", background=self.palette["bg"])
        style.configure("Panel.TFrame", background=self.palette["panel"])
        style.configure("AltPanel.TFrame", background=self.palette["panel_alt"])

        style.configure(
            "Title.TLabel",
            background=self.palette["bg"],
            foreground="#f9fafb",
            font=("Segoe UI Semibold", 21),
        )
        style.configure(
            "SubTitle.TLabel",
            background=self.palette["bg"],
            foreground=self.palette["muted"],
            font=("Segoe UI", 10),
        )
        style.configure(
            "PanelTitle.TLabel",
            background=self.palette["panel"],
            foreground="#f8fafc",
            font=("Segoe UI Semibold", 12),
        )
        style.configure(
            "Body.TLabel",
            background=self.palette["panel"],
            foreground=self.palette["text"],
            font=("Consolas", 10),
        )
        style.configure(
            "Muted.TLabel",
            background=self.palette["panel"],
            foreground=self.palette["muted"],
            font=("Segoe UI", 9),
        )

        style.configure(
            "Accent.TButton",
            background=self.palette["accent"],
            foreground="#001219",
            borderwidth=0,
            focusthickness=3,
            focuscolor=self.palette["accent"],
            padding=(12, 8),
            font=("Segoe UI Semibold", 10),
        )
        style.map(
            "Accent.TButton",
            background=[("active", "#22d3ee"), ("disabled", "#155e75")],
            foreground=[("disabled", "#9ca3af")],
        )

        style.configure(
            "Ghost.TButton",
            background="#334155",
            foreground="#e2e8f0",
            borderwidth=0,
            padding=(10, 8),
            font=("Segoe UI", 10),
        )
        style.map(
            "Ghost.TButton",
            background=[("active", "#475569"), ("disabled", "#1e293b")],
            foreground=[("disabled", "#64748b")],
        )

        style.configure(
            "Input.TEntry",
            fieldbackground="#0b1220",
            foreground="#f8fafc",
            insertcolor="#f8fafc",
            bordercolor="#334155",
            lightcolor="#334155",
            darkcolor="#334155",
            padding=8,
            font=("Segoe UI", 11),
        )

        style.configure(
            "Scale.Horizontal.TScale",
            background=self.palette["panel"],
            troughcolor="#334155",
        )

    def _build_ui(self) -> None:
        main = ttk.Frame(self.root, style="Main.TFrame", padding=18)
        main.pack(fill="both", expand=True)

        header = ttk.Frame(main, style="Main.TFrame")
        header.pack(fill="x", pady=(0, 14))

        ttk.Label(header, text="Packet Flow Visualizer", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Watch encapsulation: Data -> Segment -> Packet -> Frame across OSI and TCP/IP layers.",
            style="SubTitle.TLabel",
        ).pack(anchor="w", pady=(3, 0))

        top = ttk.Frame(main, style="Main.TFrame")
        top.pack(fill="x", pady=(0, 12))

        input_panel = ttk.Frame(top, style="Panel.TFrame", padding=12)
        input_panel.pack(fill="x", side="left", expand=True)

        ttk.Label(input_panel, text="Message", style="PanelTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.message_var = tk.StringVar(value="Hello")
        self.msg_entry = ttk.Entry(input_panel, textvariable=self.message_var, style="Input.TEntry", width=42)
        self.msg_entry.grid(row=1, column=0, padx=(0, 10), pady=(8, 0), sticky="we")

        controls = ttk.Frame(input_panel, style="Panel.TFrame")
        controls.grid(row=1, column=1, sticky="e", pady=(8, 0))

        self.start_btn = ttk.Button(controls, text="Start", style="Accent.TButton", command=self.start)
        self.start_btn.grid(row=0, column=0, padx=4)

        self.next_btn = ttk.Button(controls, text="Next Step", style="Ghost.TButton", command=self.handle_next)
        self.next_btn.grid(row=0, column=1, padx=4)

        self.reset_btn = ttk.Button(controls, text="Reset", style="Ghost.TButton", command=self.reset)
        self.reset_btn.grid(row=0, column=2, padx=4)

        speed_row = ttk.Frame(input_panel, style="Panel.TFrame")
        speed_row.grid(row=2, column=0, columnspan=2, sticky="we", pady=(10, 0))
        ttk.Label(speed_row, text="Animation speed", style="Muted.TLabel").pack(side="left")
        self.speed_var = tk.IntVar(value=1200)
        self.speed_scale = ttk.Scale(
            speed_row,
            from_=500,
            to=2200,
            orient="horizontal",
            variable=self.speed_var,
            style="Scale.Horizontal.TScale",
            length=240,
        )
        self.speed_scale.pack(side="left", padx=12)

        input_panel.columnconfigure(0, weight=1)

        body = ttk.Frame(main, style="Main.TFrame")
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=2)
        body.columnconfigure(1, weight=3)
        body.rowconfigure(0, weight=1)

        left_panel = ttk.Frame(body, style="Panel.TFrame", padding=12)
        left_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        ttk.Label(left_panel, text="Layer Progress", style="PanelTitle.TLabel").pack(anchor="w", pady=(0, 8))

        self.layer_widgets = []
        for idx, step in enumerate(self.steps):
            card = tk.Frame(left_panel, bg="#1e293b", highlightthickness=1, highlightbackground="#334155")
            card.pack(fill="x", pady=5)

            dot = tk.Canvas(card, width=16, height=16, bg="#1e293b", highlightthickness=0)
            dot.grid(row=0, column=0, rowspan=2, padx=(8, 6), pady=8)
            dot.create_oval(3, 3, 13, 13, fill="#475569", outline="")

            name = tk.Label(card, text=f"{idx + 1}. {step.name}", bg="#1e293b", fg="#e5e7eb", font=("Segoe UI Semibold", 11), anchor="w")
            name.grid(row=0, column=1, sticky="w", pady=(7, 0))

            model = tk.Label(card, text=step.model, bg="#1e293b", fg="#94a3b8", font=("Consolas", 9), anchor="w")
            model.grid(row=1, column=1, sticky="w", pady=(0, 7))

            card.columnconfigure(1, weight=1)
            self.layer_widgets.append({"card": card, "dot": dot, "name": name, "model": model})

        right_panel = ttk.Frame(body, style="AltPanel.TFrame", padding=12)
        right_panel.grid(row=0, column=1, sticky="nsew")
        right_panel.rowconfigure(1, weight=1)

        ttk.Label(right_panel, text="Transformation Details", background=self.palette["panel_alt"], foreground="#f8fafc", font=("Segoe UI Semibold", 12)).grid(row=0, column=0, sticky="w")

        self.details = tk.Text(
            right_panel,
            bg="#0b1220",
            fg="#d1d5db",
            insertbackground="#d1d5db",
            relief="flat",
            wrap="word",
            padx=10,
            pady=10,
            font=("Consolas", 10),
        )
        self.details.grid(row=1, column=0, sticky="nsew", pady=(8, 8))

        ttk.Label(right_panel, text="Wire View", background=self.palette["panel_alt"], foreground="#f8fafc", font=("Segoe UI Semibold", 12)).grid(row=2, column=0, sticky="w")

        self.wire = tk.Text(
            right_panel,
            bg="#020617",
            fg="#e2e8f0",
            relief="flat",
            height=8,
            wrap="none",
            padx=10,
            pady=10,
            font=("Consolas", 10),
        )
        self.wire.grid(row=3, column=0, sticky="ew", pady=(8, 0))

        self.status_var = tk.StringVar(value="Ready")
        status = ttk.Label(main, textvariable=self.status_var, style="SubTitle.TLabel")
        status.pack(anchor="w", pady=(10, 0))

    def start(self) -> None:
        if self.is_running:
            self.is_running = False
            self.start_btn.configure(text="Start")
            self.status_var.set("Paused")
            if self.after_id is not None:
                self.root.after_cancel(self.after_id)
                self.after_id = None
            return

        if self.current_step >= len(self.steps) - 1:
            self.reset()

        self.is_running = True
        self.start_btn.configure(text="Pause")
        self.status_var.set("Simulation running")
        self._auto_advance()

    def _auto_advance(self) -> None:
        if not self.is_running:
            return

        done = self.next_step(auto=True)
        if done:
            self.is_running = False
            self.start_btn.configure(text="Start")
            self.status_var.set("Transmission complete")
            return

        delay = int(self.speed_var.get())
        self.after_id = self.root.after(delay, self._auto_advance)

    def reset(self) -> None:
        if self.after_id is not None:
            self.root.after_cancel(self.after_id)
            self.after_id = None
        self.is_running = False
        self.current_step = -1
        self.start_btn.configure(text="Start")
        self.status_var.set("Ready")
        self._render_idle_state()

    def handle_next(self) -> None:
        if self.is_running:
            self.is_running = False
            self.start_btn.configure(text="Start")
            if self.after_id is not None:
                self.root.after_cancel(self.after_id)
                self.after_id = None
        self.next_step(auto=False)

    def next_step(self, auto: bool = False) -> bool:
        message = self.message_var.get().strip()
        if not message:
            self.status_var.set("Enter a non-empty message")
            if not auto:
                self.msg_entry.focus_set()
            return False

        if self.current_step >= len(self.steps) - 1:
            if not auto:
                self.status_var.set("Already at final layer. Press Reset to run again.")
            return True

        self.current_step += 1
        self._render_step(message, self.current_step)
        return self.current_step >= len(self.steps) - 1

    def _render_idle_state(self) -> None:
        self._update_layer_cards(-1)

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        intro = (
            "Welcome to the Packet Flow Visualizer.\n\n"
            "Type a message and press Start (auto) or Next Step (manual).\n"
            "You will see encapsulation happen across both models:\n"
            "Data -> TCP Segment -> IP Packet -> Ethernet Frame\n\n"
            f"Session started: {now}"
        )

        self.details.config(state="normal")
        self.details.delete("1.0", "end")
        self.details.insert("1.0", intro)
        self.details.config(state="disabled")

        self.wire.config(state="normal")
        self.wire.delete("1.0", "end")
        self.wire.insert("1.0", "[No transmission yet]")
        self.wire.config(state="disabled")

    def _render_step(self, message: str, idx: int) -> None:
        self._update_layer_cards(idx)

        stage = self._build_packet_forms(message)
        step = self.steps[idx]

        detail_text = [
            f"Step {idx + 1}: {step.name}",
            f"Model mapping: {step.model}",
            "",
            f"Action: {step.action}",
            "",
            "Current representation:",
            stage[idx][1],
        ]

        self.details.config(state="normal")
        self.details.delete("1.0", "end")
        self.details.insert("1.0", "\n".join(detail_text))
        self.details.config(state="disabled")

        wire_text = "\n\n".join([f"{name}\n{value}" for name, value in stage[: idx + 1]])
        self.wire.config(state="normal")
        self.wire.delete("1.0", "end")
        self.wire.insert("1.0", wire_text)
        self.wire.config(state="disabled")

        self.status_var.set(f"{step.name} complete")

    def _build_packet_forms(self, message: str):
        data = f"DATA: '{message}'"
        segment = (
            "TCP SEGMENT\n"
            "[TCP Header: src_port=49152, dst_port=80, seq=1001, ack=0, flags=SYN|ACK]\n"
            f"[Payload: '{message}']"
        )
        packet = (
            "IP PACKET\n"
            "[IP Header: src=192.168.1.10, dst=93.184.216.34, ttl=64, proto=TCP]\n"
            "[Encapsulated: TCP Segment]"
        )
        frame = (
            "ETHERNET FRAME\n"
            "[Ethernet Header: src_mac=AA:BB:CC:DD:EE:01, dst_mac=11:22:33:44:55:66, type=0x0800]\n"
            "[Encapsulated: IP Packet]\n"
            "[FCS Trailer: 0x4A3F9C1D]"
        )
        return [
            ("Application", data),
            ("Transport", segment),
            ("Internet", packet),
            ("Network Access", frame),
        ]

    def _update_layer_cards(self, active_idx: int) -> None:
        for idx, widget in enumerate(self.layer_widgets):
            card = widget["card"]
            dot = widget["dot"]
            name = widget["name"]
            model = widget["model"]

            dot.delete("all")
            if idx < active_idx:
                card.configure(bg="#064e3b", highlightbackground="#10b981")
                name.configure(bg="#064e3b")
                model.configure(bg="#064e3b")
                dot.configure(bg="#064e3b")
                dot.create_oval(3, 3, 13, 13, fill="#34d399", outline="")
            elif idx == active_idx:
                card.configure(bg="#0c4a6e", highlightbackground="#06b6d4")
                name.configure(bg="#0c4a6e")
                model.configure(bg="#0c4a6e")
                dot.configure(bg="#0c4a6e")
                dot.create_oval(3, 3, 13, 13, fill="#22d3ee", outline="")
            else:
                card.configure(bg="#1e293b", highlightbackground="#334155")
                name.configure(bg="#1e293b")
                model.configure(bg="#1e293b")
                dot.configure(bg="#1e293b")
                dot.create_oval(3, 3, 13, 13, fill="#64748b", outline="")


def main() -> None:
    root = tk.Tk()
    app = PacketFlowVisualizer(root)
    root.mainloop()


if __name__ == "__main__":
    main()
